import React from 'react';

const Logo = ({ size = 20, className = "" }) => {
    return (
        <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 40 40"
            width={size}
            height={size}
            className={className}
            style={{ display: 'block', flexShrink: 0 }}
        >
            <path
                fill="#0052FF"
                d="M20.032 28.5c-4.705 0-8.516-3.804-8.516-8.5s3.81-8.5 8.516-8.5a8.51 8.51 0 0 1 8.388 7.083H37C36.276 9.857 28.96 3 20.032 3 10.629 3 3 10.615 3 20s7.629 17 17.032 17C28.959 37 36.276 30.143 37 21.417h-8.58a8.51 8.51 0 0 1-8.388 7.083"
            />
        </svg>
    );
};

export default Logo;
