import React, { createContext, useContext, useState, useEffect } from 'react';
import { jwtDecode } from 'jwt-decode';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check if token is expired
  const isTokenExpired = (token) => {
    if (!token) return true;

    try {
      const decoded = jwtDecode(token);
      const currentTime = Date.now() / 1000;
      return decoded.exp < currentTime;
    } catch (error) {
      return true;
    }
  };

  // Generate mock JWT token
  const generateMockJWT = (userData) => {
    const header = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
    const payload = btoa(JSON.stringify({
      sub: userData.id,
      email: userData.email,
      name: userData.name,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60) // 24 hours
    }));
    const signature = btoa('mock-signature');
    return `${header}.${payload}.${signature}`;
  };

  useEffect(() => {
    // Check for stored token and user data on mount
    const storedToken = localStorage.getItem('coinbase_token');
    const storedUser = localStorage.getItem('coinbase_user');

    if (storedToken && storedUser && !isTokenExpired(storedToken)) {
      setToken(storedToken);
      setUser(JSON.parse(storedUser));
    } else if (storedToken) {
      // Token expired, clear storage
      localStorage.removeItem('coinbase_token');
      localStorage.removeItem('coinbase_user');
    }

    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  }, []);

  // Auto-logout when token expires
  useEffect(() => {
    if (!token) return;

    const checkTokenExpiry = () => {
      if (isTokenExpired(token)) {
        logout();
      }
    };

    const interval = setInterval(checkTokenExpiry, 60000); // Check every minute

    return () => clearInterval(interval);
  }, [token]);

  // Helper to get registered users from localStorage
  const getRegisteredUsers = () => {
    try {
      const users = localStorage.getItem('coinbase_registered_users');
      return users ? JSON.parse(users) : [];
    } catch (e) {
      return [];
    }
  };

  // Helper to save registered users to localStorage
  const saveRegisteredUsers = (users) => {
    localStorage.setItem('coinbase_registered_users', JSON.stringify(users));
  };

  const login = async (email, password) => {
    setIsLoading(true);
    try {
      // Simulate API call - in real app, this would be an API request
      await new Promise(resolve => setTimeout(resolve, 1000));

      const users = getRegisteredUsers();
      const userMatch = users.find(u => u.email === email && u.password === password);

      if (!userMatch) {
        return { success: false, error: 'Invalid credentials' };
      }

      // Generate mock JWT token
      const jwtToken = generateMockJWT(userMatch);

      setUser(userMatch);
      setToken(jwtToken);
      localStorage.setItem('coinbase_user', JSON.stringify(userMatch));
      localStorage.setItem('coinbase_token', jwtToken);

      return { success: true };
    } catch (error) {
      return { success: false, error: 'Login failed' };
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (email, password, name) => {
    setIsLoading(true);
    try {
      // Simulate API call - in real app, this would be an API request
      await new Promise(resolve => setTimeout(resolve, 1000));

      const users = getRegisteredUsers();
      if (users.some(u => u.email === email)) {
        return { success: false, error: 'User already exists' };
      }

      // Mock user data
      const userData = {
        id: Date.now().toString(),
        email: email,
        password: password, // In a real app, passwords must NEVER be saved in plain text
        name: name || email.split('@')[0],
        createdAt: new Date().toISOString()
      };

      // Add and save user
      users.push(userData);
      saveRegisteredUsers(users);

      // Generate mock JWT token
      const jwtToken = generateMockJWT(userData);

      setUser(userData);
      setToken(jwtToken);
      localStorage.setItem('coinbase_user', JSON.stringify(userData));
      localStorage.setItem('coinbase_token', jwtToken);

      return { success: true };
    } catch (error) {
      return { success: false, error: 'Registration failed' };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('coinbase_user');
    localStorage.removeItem('coinbase_token');
  };

  const refreshToken = async () => {
    if (!token || isTokenExpired(token)) {
      logout();
      return { success: false, error: 'Token expired' };
    }

    try {
      // Simulate token refresh API call
      await new Promise(resolve => setTimeout(resolve, 500));

      const userData = JSON.parse(localStorage.getItem('coinbase_user'));
      const newToken = generateMockJWT(userData);

      setToken(newToken);
      localStorage.setItem('coinbase_token', newToken);

      return { success: true };
    } catch (error) {
      logout();
      return { success: false, error: 'Token refresh failed' };
    }
  };

  const value = {
    user,
    token,
    isLoading,
    login,
    register,
    logout,
    refreshToken,
    isAuthenticated: !!token && !isTokenExpired(token)
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
